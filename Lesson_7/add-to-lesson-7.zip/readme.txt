LESSON 7
========
Build a Website From Scratch with HTML & CSS

Brad Hussey
bradhussey.ca

September 2013
========

Add the contents of this folder in your "Lesson_7" folder.